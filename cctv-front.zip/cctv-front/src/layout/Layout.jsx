import { Footer } from '@/components/UI/Footer'
import { Header } from '@/components/UI/Header'
import Head from 'next/head'
import { ParticlesBackground } from '@/components/UI/Particles/ParticlesBackground'
import { License } from '@/components/License'

export const Layout = ({ title = 'Robotech CCTV', children }) => {
  return (
    <>
      <Head>
        <title>{title}</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta
          name="description"
          content="cctv panel for streaming live camera video"
        />
        <meta name="author" content="Robotech" />
      </Head>
      <License>
        <Header />
        <main>
          <ParticlesBackground />
          {children}
        </main>
        <Footer />
      </License>
    </>
  )
}
