import { ChannelsContainer } from '@/components/Channels/ChannelsContainer'
import { ChannelsFilter } from '@/components/Channels/ChannelsFilter'
import { useChannelsNumberFilter } from '@/hooks/useChannelsNumberFilter'
import { Layout } from 'layout/Layout'
import { useMemo } from 'react'

export default function Home() {
  const { setChannelsNumberFilter, getChannelsNumberFilter } =
    useChannelsNumberFilter()

  const cameraNumber = useMemo(
    () => getChannelsNumberFilter(),
    [setChannelsNumberFilter]
  )

  return (
    <Layout>
      <ChannelsFilter
        setValue={setChannelsNumberFilter}
        cameraNumber={cameraNumber}
      />
      <ChannelsContainer cameraNumber={cameraNumber} />
    </Layout>
  )
}
