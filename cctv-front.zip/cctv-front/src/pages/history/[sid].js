import { useCallback, useMemo, useState } from 'react'
import { DatePicker } from '@/components/history/DatePicker'
import { Layout } from 'layout/Layout'
import { useRouter } from 'next/router'
import { HistoryPlayer } from '@/components/history/HistoryPlayer'

export default function HistoryPage() {
  const { query } = useRouter()

  const [selectedDate, setSelectedDate] = useState(new Date())
  // fix offset of local and utc date
  const utcSelectedDate = useMemo(
    () =>
      new Date(
        selectedDate.getTime() - selectedDate.getTimezoneOffset() * 60000
      ),
    [selectedDate, query.sid]
  )

  const videoSrc = useMemo(
    () =>
      query.sid
        ? `${process.env.NEXT_PUBLIC_BUCKET_PATH}/${utcSelectedDate
            .toISOString()
            .slice(0, 10)}/stream${query.sid}/output.m3u8`
        : null,
    [utcSelectedDate]
  )

  const handleDateChange = useCallback(
    (date) => {
      setSelectedDate(date)
    },
    [selectedDate]
  )

  return (
    <Layout title="playback history">
      <section className="grid grid-cols-12 grid-rows-1 max-w-7xl mx-auto px-4 xl:px-0 gap-4 items-start">
        <div className="col-span-8 bg-zinc-800 bg-opacity-50 backdrop-blur-md p-4 rounded-md border-2 border-gray-500 pb-14">
          <HistoryPlayer url={videoSrc} history />
        </div>
        <div className="col-span-4 bg-zinc-800 bg-opacity-50 backdrop-blur-md p-4 rounded-md border-2 border-gray-500">
          <DatePicker
            selectedDate={selectedDate}
            handleDateChange={handleDateChange}
          />
        </div>
      </section>
    </Layout>
  )
}
