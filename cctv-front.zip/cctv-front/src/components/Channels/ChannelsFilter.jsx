import { ListBulletIcon } from '@heroicons/react/24/solid'

export const ChannelsFilter = ({ setValue, cameraNumber }) => {
  return (
    <div className="max-w-7xl mx-4 xl:mx-auto  text-[14px] rounded-md mb-4 flex items-center justify-between">
      <div className="flex items-center justify-center text-white">
        <ListBulletIcon className="w-6 h-6 text-gray-100" />
        <span className="font-semibold mx-1">{cameraNumber} </span> Channels
      </div>
      <div>
        <label className="text-white mr-2">Channels number</label>
        <select
          className="cursor-pointer focus:outline-0 rounded-md p-0.5"
          onChange={(event) => setValue(event.target.value)}
          value={cameraNumber}
        >
          <option value={1}>1</option>
          <option value={2}>2</option>
          <option value={3}>3</option>
          <option value={4}>4</option>
          <option value={5}>5</option>
          <option value={6}>6</option>
          <option value={7}>7</option>
          <option value={8}>8</option>
          <option value={9}>9</option>
          <option value={10}>10</option>
          <option value={11}>11</option>
          <option value={12}>12</option>
          <option value={13}>13</option>
          <option value={14}>14</option>
          <option value={15}>15</option>
          <option value={16}>16</option>
        </select>
      </div>
    </div>
  )
}
