import { FeedsContainer } from '../Feeds/FeedsContainer'

export const ChannelsContainer = ({ cameraNumber }) => {
  return (
    <section className="max-w-7xl mx-4 xl:mx-auto border-2 border-gray-500 bg-zinc-800 bg-opacity-50 backdrop-blur-md rounded-md p-3 text-white text-[14px]">
      <FeedsContainer cameraNumber={cameraNumber} />
    </section>
  )
}
