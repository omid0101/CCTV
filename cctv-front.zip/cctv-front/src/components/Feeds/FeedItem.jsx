import { useCallback, useMemo, useState } from 'react'
import { VideoPlayer } from '../UI/VideoPlayer'
import { SignalSlashIcon } from '@heroicons/react/24/solid'

export const FeedItem = ({ fid }) => {
  const [error, setError] = useState(false)

  const videoSrc = useMemo(
    () =>
      `${process.env.NEXT_PUBLIC_BUCKET_PATH}/${new Date()
        .toISOString()
        .slice(0, 10)}/stream${fid}/output.m3u8`,
    [fid]
  )

  const handleError = useCallback(() => {
    setError(true)
  }, [])
  return (
    <li className="w-full h-auto rounded-md">
      <div className="flex items-center">
        <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse mr-1" />
        <label className="text-gray-100 text-[13px] flex items-center">
          Camera {fid} -
          {error ? (
            <p className="ml-1 bg-red-500 text-white p-1 rounded-md tracking-wide">
              Offline
            </p>
          ) : (
            <p className="ml-1 bg-green-500 text-white p-1 rounded-md tracking-wide">
              Online
            </p>
          )}
        </label>
      </div>
      {error ? (
        <div className="w-full h-[300px] bg-gray-500 rounded-md flex items-center justify-center mt-3">
          <SignalSlashIcon className="w-6 h-6" />
          <p className="text-gray-100 text-[14px] ml-1">Offline</p>
        </div>
      ) : (
        <div className="w-full h-[300px]">
          <VideoPlayer
            url={videoSrc}
            onErrorHandler={handleError}
            streamId={fid}
          />
        </div>
      )}
    </li>
  )
}
