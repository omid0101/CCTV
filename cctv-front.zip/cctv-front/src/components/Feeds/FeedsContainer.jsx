import { useCallback } from 'react'
import { FeedItem } from './FeedItem'

export const FeedsContainer = ({ cameraNumber }) => {
  const arrayCreator = useCallback((n) => {
    return Array.from({ length: n }, (_, i) => i + 1)
  }, [])

  return (
    <ul className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 divider gap-x-4 gap-y-14 pb-10">
      {arrayCreator(cameraNumber)?.map((cid) => (
        <FeedItem fid={cid} key={cid} />
      ))}
    </ul>
  )
}
