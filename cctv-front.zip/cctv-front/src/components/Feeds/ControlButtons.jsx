import Link from 'next/link'
import {
  EyeIcon,
  FilmIcon,
  SpeakerWaveIcon,
  SpeakerXMarkIcon,
} from '@heroicons/react/24/solid'
export const ControlButtons = ({
  handleReset,
  handleAudio,
  isMuted,
  streamId,
}) => {
  return (
    <div className="flex items-base ml-1 space-x-3 mt-3">
      <i
        className="p-1 rounded-md flex items-center justify-center cursor-pointer bg-gray-200 group hover:bg-gray-100 transition-all duration-200 ease-in-out"
        title="reset zoom scale"
      >
        <EyeIcon
          className="w-5 h-5 text-gray-700 group-hover:text-green-500 transition-all duration-200 ease-in-out"
          onClick={handleReset}
        />
      </i>

      {isMuted ? (
        <i
          className="p-1 rounded-md flex items-center justify-center cursor-pointer bg-gray-200 group hover:bg-gray-100 transition-all duration-200 ease-in-out"
          title="mute"
        >
          <SpeakerXMarkIcon
            className="w-5 h-5 text-gray-700 group-hover:text-green-500 transition-all duration-200 ease-in-out"
            onClick={handleAudio}
          />
        </i>
      ) : (
        <i
          className="p-1 rounded-md flex items-center justify-center cursor-pointer bg-gray-200 group hover:bg-gray-100 transition-all duration-200 ease-in-out"
          title="unmute"
        >
          <SpeakerWaveIcon
            className="w-5 h-5 text-gray-700 group-hover:text-green-500 transition-all duration-200 ease-in-out"
            onClick={handleAudio}
          />
        </i>
      )}

      <Link href={`/history/${streamId}`}>
        <i
          className="p-1 rounded-md flex items-center justify-center cursor-pointer bg-gray-200 group hover:bg-gray-100 transition-all duration-200 ease-in-out"
          title="history"
        >
          <FilmIcon className="w-5 h-5 text-gray-700 group-hover:text-green-500 transition-all duration-200 ease-in-out" />
        </i>
      </Link>
    </div>
  )
}
