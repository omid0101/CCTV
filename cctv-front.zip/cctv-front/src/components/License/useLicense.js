export const useLicense = () => {
  const getSession = () => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('lkey')
    }
    return null
  }
  const setSession = (value) => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('lkey', value)
      return
    }
    return null
  }

  return { setSession, getSession }
}
