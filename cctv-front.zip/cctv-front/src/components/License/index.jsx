import { useEffect, useState } from 'react'
import { KeyIcon, ShieldExclamationIcon } from '@heroicons/react/24/solid'
import axios from 'axios'
import { useLicense } from './useLicense'
export const License = (props) => {
  const [isVerify, setIsVerify] = useState(false)
  const [license, setLicense] = useState('')
  const [error, setError] = useState(null)
  const { getSession, setSession } = useLicense()

  const licenseInputHandler = (value) => {
    setLicense(value)
  }

  const checkKey = async (key) => {
    try {
      const response = await axios.post(process.env.NEXT_PUBLIC_LICENSE, {
        key,
      })
      const data = response.data
      if (data.isEqual && !data.isExpire) {
        setIsVerify(true)
      } else if (data.isEqual && data.isExpire) {
        setIsVerify(false)
        setError('Your License Key Expired!')
      }
    } catch (error) {
      setIsVerify(false)
      if (error.response?.data) setError(error.response.data?.message)
      // when license server not work
      else setError('Somthing went Wrong!')
    }
  }

  useEffect(() => {
    const lkey = getSession()
    if (lkey) {
      checkKey(lkey)
    }
  }, [])

  const submitHandler = async () => {
    if (license.trim() === '') setError('License Field Is Empty!')
    else {
      checkKey(license)
    }
  }

  if (!isVerify) {
    return (
      <>
        <div className="justify-center items-center flex overflow-x-hidden overflow-y-auto fixed inset-0 z-50 outline-none focus:outline-none">
          <div className="relative w-[50%] xl:w-[35 %] my-6 mx-auto max-w-3xl">
            {/*content*/}
            <div className="border-0 rounded-lg shadow-lg relative flex flex-col w-full bg-zinc-700 outline-none focus:outline-none">
              {/*header*/}
              <div className="flex items-start justify-between p-5 border-b border-solid border-zinc-200 rounded-t">
                <div className="flex items-center">
                  <KeyIcon className="w-5 h-5 text-gray-200" />
                  <h3 className="text-lg text-gray-200 font-semibold ml-1">
                    License
                  </h3>
                </div>
                <button
                  className="p-1 ml-auto bg-transparent border-0 text-black opacity-5 float-right text-3xl leading-none font-semibold outline-none focus:outline-none"
                  onClick={() => setShowModal(false)}
                >
                  <span className="bg-transparent text-black opacity-5 h-6 w-6 text-2xl block outline-none focus:outline-none">
                    ×
                  </span>
                </button>
              </div>
              {/*body*/}
              <div className="relative p-6 flex-auto">
                <input
                  type="text"
                  name="license-field"
                  id="license-field"
                  className="p-3 bg-zinc-600 rounded-md w-full outline-0 focus:outline-2 outline-indigo-500 text-gray-200 text-sm"
                  placeholder="Insert Your License..."
                  onChange={(event) => licenseInputHandler(event.target.value)}
                />

                {error && (
                  <div className="flex items-center mt-4">
                    <i>
                      <ShieldExclamationIcon className="w-6 h-6 text-red-500 mr-1" />
                    </i>
                    <p className="bg-red-500  text-gray-100 p-1 rounded-md font-semibold  text-sm leading-4">
                      {error}
                    </p>
                  </div>
                )}
              </div>
              {/*footer*/}
              <div className="flex items-center justify-end p-6 border-t border-solid border-zinc-200 rounded-b">
                <button
                  className="bg-emerald-500 text-white active:bg-emerald-600 font-bold uppercase text-sm px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
                  type="button"
                  onClick={submitHandler}
                >
                  Submit
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="opacity-25 fixed inset-0 z-40 bg-black"></div>
      </>
    )
  }

  return <>{props.children}</>
}
