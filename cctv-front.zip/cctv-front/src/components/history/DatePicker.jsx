import ReactDatePicker from 'react-datepicker'
import 'react-datepicker/dist/react-datepicker.css'
import { subDays } from 'date-fns'
import { CalendarDaysIcon } from '@heroicons/react/24/solid'

export const DatePicker = ({ selectedDate, handleDateChange }) => {
  return (
    <div className="relative">
      <ReactDatePicker
        selected={selectedDate}
        onChange={(date) => {
          handleDateChange(date)
        }}
        minDate={subDays(new Date(), 6)}
        maxDate={new Date()}
        className="p-2 w-full rounded-md cursor-pointer focus:outline-0"
      />
      <i className="absolute right-2 top-2">
        <CalendarDaysIcon className="w-6 h-6 text-gray-500" />
      </i>
    </div>
  )
}
