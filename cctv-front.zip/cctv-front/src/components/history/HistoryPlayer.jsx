import { VideoPlayer } from '@/components/UI/VideoPlayer'
export const HistoryPlayer = ({ url, history }) => {
  if (!url) {
    return <p className="text-white">Video Source Not Found!</p>
  }

  return (
    <div className="w-full h-[480px]">
      <VideoPlayer url={url} history />
    </div>
  )
}
