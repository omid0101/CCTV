import { useState, useEffect, useRef } from 'react'
import videojs from 'video.js'
import 'video.js/dist/video-js.css'
import { ControlButtons } from '../Feeds/ControlButtons'

export const VideoPlayer = ({ url, onErrorHandler, streamId, history }) => {
  const playerRef = useRef(null)
  const [player, setPlayer] = useState(null)
  const [scale, setScale] = useState(1)
  const [isDragging, setIsDragging] = useState(false)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })
  const [isMuted, setIsMuted] = useState(true)

  useEffect(() => {
    return () => {
      if (player) {
        player.dispose()
      }
    }
  }, [])

  useEffect(() => {
    if (player) {
      player.on('error', (err) => {
        onErrorHandler(err)
      })
      return () => {
        if (player) {
          player.dispose()
        }
      }
    }
  }, [player])

  useEffect(() => {
    if (player) {
      player.src({
        src: url,
        type: 'application/x-mpegURL',
      })
    }
  }, [url])

  const handlePlayerReady = (player) => {
    setPlayer(player)

    !history &&
      player.on('loadedmetadata', function () {
        const seekableRanges = player.seekable()

        if (seekableRanges.length > 0) {
          const lastSeekableRangeEnd = seekableRanges.end(
            seekableRanges.length - 1
          )
          player.duration(lastSeekableRangeEnd)
          player.currentTime(lastSeekableRangeEnd)
        }
      })
  }

  const handleWheel = (event) => {
    if (player) {
      const videoElement = player.el().querySelector('video')
      const delta = event.deltaY > 0 ? -0.1 : 0.1
      const newScale = Math.max(0.1, Math.min(scale + delta, 3))
      setScale(newScale)
      videoElement.style.transform = `scale(${newScale})`
    }
  }

  const handleMouseDown = (event) => {
    setIsDragging(true)
    setDragStart({ x: event.clientX, y: event.clientY })
  }

  const handleMouseMove = (event) => {
    if (isDragging && player) {
      const videoElement = player.el().querySelector('video')
      const deltaX = event.clientX - dragStart.x
      const deltaY = event.clientY - dragStart.y
      videoElement.style.left = `${
        parseFloat(videoElement.style.left) + deltaX
      }px`
      videoElement.style.top = `${
        parseFloat(videoElement.style.top) + deltaY
      }px`
      setDragStart({ x: event.clientX, y: event.clientY })
    }
  }

  const handleMouseUp = () => {
    setIsDragging(false)
  }

  const handleReset = () => {
    setScale(1)
    const videoElement = player.el().querySelector('video')
    videoElement.style.left = '0'
    videoElement.style.top = '0'
    videoElement.style.transform = 'scale(1)'
  }

  const handleFullScreen = () => {
    if (player) {
      if (player.isFullscreen()) {
        player?.exitFullscreen()
      } else {
        player.requestFullscreen()
      }
    }
  }

  const handleAudio = () => {
    setIsMuted((prevState) => !prevState)
  }

  useEffect(() => {
    const videoNode = playerRef.current

    const videoPlayer = videojs(
      videoNode,
      {
        liveui: true,
      },
      () => {
        handlePlayerReady(videoPlayer)
      }
    )
  }, [])

  return (
    <>
      <div className="relative w-full h-full mt-3 overflow-hidden">
        <video
          onWheel={handleWheel}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onDoubleClick={history ? null : handleFullScreen}
          ref={playerRef}
          className="w-full video-js overflow-hidden vjs-big-play-centered object-cover h-full rounded-md"
          preload="auto"
          autoPlay
          muted={isMuted}
          style={{ left: 0, top: 0 }}
          controls={history}
        >
          <source src={url} type="application/x-mpegURL" />
        </video>
      </div>

      {!history && (
        <ControlButtons
          handleAudio={handleAudio}
          handleReset={handleReset}
          isMuted={isMuted}
          streamId={streamId}
        />
      )}
      {history && (
        <button
          onClick={handleReset}
          className="mt-4 bg-gray-200 text-sm p-1 rounded-md font-semibold text-gray-700 hover:bg-gray-300 transition-all duration-200 ease-in-out"
        >
          Reset Zoom
        </button>
      )}
    </>
  )
}
