import { useMemo } from 'react'

export const Footer = () => {
  const year = useMemo(() => new Date().getFullYear(), [])
  return (
    <footer className="max-w-7xl p-3 mx-4 xl:mx-auto bg-zinc-800 bg-opacity-50 backdrop-blur-md my-4 border-2 border-gray-500 rounded-md flex items-center justify-center">
      <span className="text-[14px] text-gray-100">
        ©️ {year} COPYRIGHT, All Right Reserved
      </span>
    </footer>
  )
}
