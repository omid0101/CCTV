import { useState, useEffect } from 'react'
import { ClockIcon } from '@heroicons/react/24/solid'

export const Clock = () => {
  const [time, setTime] = useState('')
  useEffect(() => {
    const timer = setInterval(() => {
      const date = new Date()
      const hours = String(date.getHours()).padStart(2, '0')
      const minutes = String(date.getMinutes()).padStart(2, '0')
      const seconds = String(date.getSeconds()).padStart(2, '0')
      const formattedTime = `${hours}:${minutes}:${seconds}`
      setTime(formattedTime)
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  return (
    <div className="flex items-center justify-center">
      <h3 className="text-gray-100 ml-1 text-[14px] tracking-wider">{time}</h3>
      <ClockIcon className="w-5 h-5 text-gray-100 ml-2" />
    </div>
  )
}
