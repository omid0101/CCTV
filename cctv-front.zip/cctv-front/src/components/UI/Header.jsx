import Image from 'next/image'
import Logo from '@/assets/cctv.svg'
import { TypeAnimation } from 'react-type-animation'
import Link from 'next/link'
import { Clock } from './Clock'
import { useRouter } from 'next/router'
import { ArrowUturnLeftIcon } from '@heroicons/react/24/solid'

export const Header = () => {
  const router = useRouter()
  return (
    <header className="bg-zinc-800 bg-opacity-50 backdrop-blur-md p-1 rounded-md max-w-7xl xl:mx-auto my-4 border-2 border-gray-500 mx-4">
      <nav className="flex justify-between items-center px-2">
        <Link href="/">
          <div className="flex items-center justify-center">
            <Image alt="svg-logo" src={Logo} width={40} height={40} />
            <TypeAnimation
              sequence={['CCTV version 1.0.0', 1000, 'Robotech Company', 2000]}
              wrapper="span"
              cursor={true}
              repeat={Infinity}
              className="text-sm text-gray-100 ml-2 text-[13px] tracking-wide"
            />
          </div>
        </Link>
        <div className="flex items-center justify-center">
          {router.asPath !== '/' && (
            <Link href="/">
              <div className="flex items-center justify-center mr-2 cursor-pointer group">
                <h4 className=" mr-1 group-hover:text-indigo-300 text-sm font-semibold text-indigo-200 transition-all duration-200 ease-in-out">
                  Home
                </h4>
                <ArrowUturnLeftIcon className="w-4 h-4 group-hover:text-indigo-300 text-indigo-200 transition-all duration-200 ease-in-out" />
              </div>
            </Link>
          )}
          <Clock />
        </div>
      </nav>
    </header>
  )
}
