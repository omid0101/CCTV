import { useState } from 'react'
export const useChannelsNumberFilter = () => {
  const [channelsLength, setChannelsLength] = useState(1)
  const setChannelsNumberFilter = (num) => setChannelsLength(num)
  const getChannelsNumberFilter = (num) => channelsLength
  return {
    setChannelsNumberFilter,
    getChannelsNumberFilter,
  }
}
